//by niki
const fs = require('fs')
//~~~~~~~~~SETTING BOT~~~~~~~~~~//
global.owner = "6288232530478" //ganti aja
global.nama = "にき" //ganti aja
global.namaowner = "にき" // Ganti aja
global.namaBot = "sora kasugano" // Ganti aja
global.ch = 'https://whatsapp.com/channel/' // Ganti aja
global.ownername = "にき" // Ganti aja
global.botname = "sora kasugano" // Ganti aja
global.status = true 
global.foother = "©sora" // Ganti aja
global.namach = 'にき' // Ganti aja
global.idch = '120363302865191524@newsletter' // diemin kalau gda
global.namafile = 'にき' // Ganti aja
global.themeemoji = '🌸' // Ganti aja
global.packname = "sᴛɪᴄᴋᴇʀ ʙʏ" // Ganti aja
global.author = "\n\n\n\n\nᴄʀᴇᴀᴛᴇ ʙʏ sora kasugano 🐼\nにき" // Ganti aja
global.creator = "6288232530478@s.whatsapp.net" // Ganti aja
global.autoswview = true //auto status/story view
//====== [ THEME URL & URL ] ========//
global.thumb = fs.readFileSync('./hoshino.jpg'); // Buffer Image
global.thumbfurina = 'https://files.catbox.moe/7i7vum.jpeg'
global.thumbnail = 'https://files.catbox.moe/7i7vum.jpeg' // Ganti aja
global.reply = 'https://files.catbox.moe/7i7vum.jpeg' // Ganti aja
global.Url = '-'
global.domain = 'https://'
global.apikey = 'plta'
global.capikey = 'pltc'
//===================== Setting Apikey V2 =========================//
global.domain2 = "https"
global.apikey2 = "ptla"
global.capikey2 = "ptlc"
//===================== Setting Apikey V3 =========================//
global.domain3 = "https://kenzstore-mujib.zackyoffc.xyz"
global.apikey3 = "ptla_h51ID3CRoGZxwAMA2OAQXSDZ5xUoGGXSBICCEICV8dM"
global.capikey3 = "ptlc_9H4b9yPFtunO8K17xcZzn1wHThwvoO9oyEW3LwIJN4I"
//===================== BIARIN!!!! =========================//
global.eggsnya = '15' // id eggs yang dipakai
global.location = '1' // id location
//~~~~~~~~~ Settings reply ~~~~~~~~~//
global.mess = {
    owner: "𝙏𝙝𝙞𝙨 𝙄𝙨 𝙁𝙤𝙧 𝙊𝙬𝙣𝙚𝙧, 𝙉𝙤𝙩 𝙁𝙤𝙧 𝙔𝙤𝙪 ´◡`",
    prem: "𝙏𝙝𝙞𝙨 𝙄𝙨 𝙁𝙤𝙧 𝙋𝙧𝙚𝙢𝙞𝙪𝙢, 𝙉𝙤𝙩 𝙁𝙤𝙧 𝙔𝙤𝙪 ´◡`",
    group: "𝙏𝙝𝙞𝙨 𝙄𝙨 𝙁𝙤𝙧 𝙂𝙧𝙤𝙪𝙥 𝙊𝙣𝙡𝙮 ´◡`",
    private: "𝙊𝙣𝙡𝙮 𝙋𝙧𝙞𝙫𝙖𝙩𝙚 𝘾𝙝𝙖𝙩 𝙎𝙞𝙧 ´◡`"
}


global.packname = 'sora kasugano 🐼' // Ganti aja
global.author = '\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n@にき' // Ganti aja
//~~~~~~~~~~~ DIEMIN ~~~~~~~~~~//
global.pairing = "" // Jangan Di Apa Apain
global.qrcode = "120363302865191524@newsletter" // Jangan Di Apa Apain

let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
  require('fs').unwatchFile(file)
  console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
  delete require.cache[file]
  require(file)
})
